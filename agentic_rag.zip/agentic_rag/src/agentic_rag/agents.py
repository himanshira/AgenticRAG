"""Agent definitions."""

from crewai import Agent

from .config import DOMAIN_DESCRIPTION, get_llm
from .tools import pdf_tool, web_tool


def router_agent() -> Agent:
    return Agent(
        role="Query Router",
        goal="Classify each question into exactly one retrieval path: pdf, web or direct.",
        backstory=(
            "You are a triage specialist. The static PDF covers: "
            f"{DOMAIN_DESCRIPTION}. Questions answerable from it go to 'pdf'. "
            "Anything about recent events, prices, news, dates or things "
            "outside the PDF's scope needs 'web'. General concepts that any "
            "well-read person could explain need 'direct'."
        ),
        llm=get_llm(),
        tools=[],  # the router only decides, it never retrieves
        allow_delegation=False,
        verbose=True,
    )


def retriever_agent() -> Agent:
    return Agent(
        role="Retriever and Answer Writer",
        goal="Retrieve evidence from the assigned source and write a grounded answer.",
        backstory=(
            "You are a meticulous researcher. You only use the tool you were told "
            "to use, cite the evidence you found, and say clearly when the source "
            "does not contain the answer instead of guessing."
        ),
        llm=get_llm(),
        tools=[pdf_tool, web_tool],
        allow_delegation=False,
        verbose=True,
    )
