"""The Flow that wires router -> retriever / direct -> final answer."""

from crewai import Crew, Process
from crewai.flow.flow import Flow, listen, or_, router, start

from .agents import retriever_agent, router_agent
from .config import get_llm
from .schemas import RAGState, RouteDecision
from .tasks import retriever_task, router_task


class AgenticRAGFlow(Flow[RAGState]):

    @start()
    def receive_question(self):
        return self.state.question

    @router(receive_question)
    def decide_route(self):
        agent = router_agent()
        crew = Crew(
            agents=[agent],
            tasks=[router_task(self.state.question, agent)],
            process=Process.sequential,
        )
        decision: RouteDecision = crew.kickoff().pydantic
        self.state.route = decision.route
        self.state.reason = decision.reason
        return decision.route  # "pdf" | "web" | "direct"

    def _retrieve(self, source: str) -> str:
        agent = retriever_agent()
        crew = Crew(
            agents=[agent],
            tasks=[retriever_task(self.state.question, source, agent)],
            process=Process.sequential,
        )
        self.state.answer = crew.kickoff().raw
        return self.state.answer

    @listen("pdf")
    def retrieve_from_pdf(self):
        return self._retrieve("pdf")

    @listen("web")
    def retrieve_from_web(self):
        return self._retrieve("web")

    @listen("direct")
    def answer_directly(self):
        # Optional generation path: plain LLM call, no agent, no tools.
        self.state.answer = get_llm().call(
            f"Answer this question clearly and concisely:\n\n{self.state.question}"
        )
        return self.state.answer

    @listen(or_(retrieve_from_pdf, retrieve_from_web, answer_directly))
    def finalize(self, answer: str) -> dict:
        return {
            "question": self.state.question,
            "route": self.state.route,
            "reason": self.state.reason,
            "answer": answer,
        }


def ask(question: str) -> dict:
    """Convenience wrapper used by main.py and any UI."""
    return AgenticRAGFlow().kickoff(inputs={"question": question})
