# Agentic RAG with CrewAI

Router agent decides the retrieval path (`pdf` | `web` | `direct`), retriever agent executes it.

## Setup

```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -e .
cp .env.example .env                                  # add your keys
# put your domain PDF at data/domain_docs.pdf
```

## Run

```bash
agentic-rag "What does the document say about X?"
# or
python -m agentic_rag.main "What does the document say about X?"
```

`agentic-rag --plot` writes `agentic_rag_flow.html`, a graph of the flow.
